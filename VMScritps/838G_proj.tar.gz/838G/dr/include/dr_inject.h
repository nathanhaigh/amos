/* **********************************************************
 * Copyright (c) 2002-2009 VMware, Inc.  All rights reserved.
 * **********************************************************/

/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 * 
 * * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * 
 * * Neither the name of VMware, Inc. nor the names of its contributors may be
 *   used to endorse or promote products derived from this software without
 *   specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL VMWARE, INC. OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */

#ifndef _DR_INJECT_H_
#define _DR_INJECT_H_ 1

#ifdef WINDOWS
/****************************************************************************
 * Injection API
 */
/**
 * @file dr_inject.h
 * @brief Injection API for Windows.  Use these functions to launch
 * processes under the control of under DynamoRIO.
 */

/**
 * Creates a new process for the executable and command line specified.
 * The initial thread in the process is suspended.
 * Use dr_inject_process_inject() to inject DynamoRIO into the process
 * (first calling dr_register_process() to configure the process, for
 * one-time targeted configuration), dr_inject_process_run() to resume
 * the thread, and dr_inject_process_exit() to finish and free
 * resources.
 *
 * \param[in]   app_name       The path to the target executable.
 *
 * \param[in]   app_cmdline    The target executable and its arguments.
 *
 * \param[out]  data           An opaque pointer that should be passed to
 *                             subsequent dr_inject_* routines to refer to
 *                             this process.
 * \return  Returns 0 on success.  On failure, returns a Windows API error code.
 *          Regardless of success, caller must call dr_inject_process_exit()
 *          when finished to clean up internally-allocated resources.
 */
int
dr_inject_process_create(const char *app_name, const char *app_cmdline,
                         void **data);

/**
 * Injects DynamoRIO into a process created by dr_inject_process_create().
 *
 * \param[in]   data           The pointer returned by dr_inject_process_create()
 *
 * \param[in]   force_injection  Requests injection even if the process is
 *                               configured to not be run under DynamoRIO.
 *
 * \param[in]   library_path    The path to the DynamoRIO library to use.  If
 *                              NULL, the library that the target process is
 *                              configured for will be used.
 *
 * \return  Whether successful.
 */
bool
dr_inject_process_inject(void *data, bool force_injection,
                         const char *library_path);

/**
 * Resumes the suspended thread in a process created by dr_inject_process_create().
 *
 * \param[in]   data           The pointer returned by dr_inject_process_create()
 *
 * \return  Whether successful.
 */
bool
dr_inject_process_run(void *data);

/**
 * Frees resources used by dr_inject_process_create().
 *
 * \param[in]   data           The pointer returned by dr_inject_process_create()
 *
 * \param[in]   terminate      If true, the process is forcibly terminated.
 *
 * \return  Returns the exit code of the process.  If the caller did not wait
 *          for the process to finish before calling this, the code will be
 *          STILL_ACTIVE.
 */
int
dr_inject_process_exit(void *data, bool terminate);

/**
 * Returns the process name of a process created by dr_inject_process_create().
 *
 * \param[in]   data           The pointer returned by dr_inject_process_create()
 *
 * \return  Returns the process name of the process.  This is the file name
 *          without the path, suitable for passing to dr_register_process().
 */
char *
dr_inject_get_image_name(void *data);

/**
 * Returns a handle to a process created by dr_inject_process_create().
 *
 * \param[in]   data           The pointer returned by dr_inject_process_create()
 *
 * \return  Returns the handle used by drinjectlib.  Do not close the handle: it
 *          will be closed in dr_inject_process_exit().
 */
HANDLE
dr_inject_get_process_handle(void *data);

/**
 * Returns the pid of a process created by dr_inject_process_create().
 *
 * \param[in]   data           The pointer returned by dr_inject_process_create()
 *
 * \return  Returns the pid of the process.
 */
process_id_t
dr_inject_get_process_id(void *data);

/* Deliberately not documented: not fully supported */
bool
dr_inject_using_debug_key(void *data);

/**
 * Prints statistics for a process created by dr_inject_process_create().
 *
 * \param[in]   data           The pointer returned by dr_inject_process_create()
 *
 * \param[in]   elapsed_secs   Elapsed time recorded by the caller that will be
 *                             printed by this routine if showstats is true.
 *
 * \param[in]   showstats      If true, elapsed_secs and resource usage is printed.
 *
 * \param[in]   showmem        If true, memory usage statistics are printed.
 */
void
dr_inject_print_stats(void *data, int elapsed_secs, bool showstats, bool showmem);

#endif /* WINDOWS */




#endif /* _DR_INJECT_H_ */
